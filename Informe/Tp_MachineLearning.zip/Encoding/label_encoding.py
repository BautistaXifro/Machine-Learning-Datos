# Donde df es el Data set original, y short_df es el Data set ya pre procesado, y listo para entrenar.
# Se toma como criterio que cualquier categoria que aparezca menos de 5 veces se considere como "Other".

dict_product_name = {k: i for i, k in enumerate(df['Product_Name'].unique())} # Label Encoding
short_df["Product_Name"] = df["Product_Name"].map(dict_product_name)