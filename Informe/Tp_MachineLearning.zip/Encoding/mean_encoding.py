# Donde df es el Data set original, y short_df es el Data set ya pre procesado, y listo para entrenar.
# Se toma como criterio que cualquier categoria que aparezca menos de 5 veces se considere como "Other".

df["Feature"] = np.where(df.groupby('Feature')["Feature"].transform(len) > 5, df["Feature"], "Other")
mean_encoded_account = df.groupby("Feature")["Target"].mean().to_dict()
short_df["Feature"] = df["Feature"].map(mean_encoded_account)
